"""Routes package initialization"""
